import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

class CustomList<T extends Comparable<T>> implements Iterable<T> {
    private List<T> elementList = new ArrayList<>();

    public void add(T element) {
        elementList.add(element);
    }

    public T remove(int idx) {
        return elementList.remove(idx);
    }

    public boolean contains(T element) {
        return elementList.contains(element);
    }

    public void swap(int first, int second) {
        Collections.swap(elementList, first, second);
    }

    public int greater(T element) {
        int count = 0;

        for (T e : elementList) {

            if (e.compareTo(element) > 0) {
                count++;
            }
        }
        return count;
    }

    public T getMax() {
        return Collections.max(elementList);
    }

    public T getMin() {
        return Collections.min(elementList);
    }

    @Override
    public Iterator<T> iterator() {
        return elementList.iterator();
    }
}

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        CustomList<String> customList = new CustomList<>();

        String input;
        while (!(input = scanner.nextLine()).equals("END")) {
            String[] data = input.split("\\s+");

            String cmd = data[0];

            switch (cmd) {

                case "Add" -> customList.add(data[1]);
                case "Remove" -> customList.remove(Integer.parseInt(data[1]));
                case "Contains" -> System.out.println(customList.contains(data[1]));

                case "Swap" -> {

                    int index1 = Integer.parseInt(data[1]);
                    int index2 = Integer.parseInt(data[2]);
                    customList.swap(index1, index2);
                }
                case "Greater" -> System.out.println(customList.greater(data[1]));
                case "Max" -> System.out.println(customList.getMax());
                case "Min" -> System.out.println(customList.getMin());

                case "Print" -> {

                    for (String e : customList) {
                        System.out.println(e);
                    }
                }
            }
        }
    }
}
