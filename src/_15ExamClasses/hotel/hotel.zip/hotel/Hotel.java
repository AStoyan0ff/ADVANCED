package hotel;

import java.util.ArrayList;
import java.util.List;

public class Hotel {

    private String name;
    private int capacity;
    private List<Person> roster;

    public Hotel(String name, int capacity) {

        this.name = name;
        this.capacity = capacity;
        this.roster = new ArrayList<>();
    }

    public void add(Person p) {

        if (roster.size() < capacity) {
            roster.add(p);
        }
    }

    public boolean remove(String name) {
        return roster.removeIf(p -> p.getName().equals(name));
    }

    public Person getPerson(String name, String hometown) {

        return roster.stream()
                .filter(p -> p.getName().equals(name) && p.getHometown().equals(hometown))
                .findFirst()
                .orElse(null);
    }

    public int getCount() {
        return roster.size();
    }

    public String getStatistics() {

        StringBuilder buff = new StringBuilder();
        buff.append("The people in the hotel ").append(name).append(" are:\n");

        for (Person p : roster) {
            buff.append(p).append("\n");
        }
        return buff.toString().trim();
    }
}
