import java.util.*;

class CustomList<T extends Comparable<T>> {

    private List<T> elementList = new ArrayList<>();

    public void add(T element) {
        elementList.add(element);
    }

    public T remove(int idx) {
        return elementList.remove(idx);
    }

    public boolean contains(T element) {
        return elementList.contains(element);
    }

    public int greater(T element) {
        int cnt = 0;

        for (T e : elementList) {

            if (e.compareTo(element) > 0) {
                cnt++;
            }
        }
        return cnt;
    }

    public T getMax() {
        return Collections.max(elementList);
    }

    public T getMin() {
        return Collections.min(elementList);
    }

    public void print() {

        for (T e : elementList) {
            System.out.println(e);
        }
    }

    public void swap(int first, int second) {
        Collections.swap(elementList, first, second);
    }
}

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        CustomList<String> customList = new CustomList<>();

        String input;
        while (!(input = scanner.nextLine()).equals("END")) {
            String[] data = input.split("\\s+");

            String cmd = data[0];
            switch (cmd) {

                case "Add":
                    customList.add(data[1]);
                    break;

                case "Remove":
                    customList.remove(Integer.parseInt(data[1]));
                    break;

                case "Contains":
                    System.out.println(customList.contains(data[1]));
                    break;

                case "Swap":
                    int firstIdx = Integer.parseInt(data[1]);
                    int secondIdx = Integer.parseInt(data[2]);
                    customList.swap(firstIdx, secondIdx);
                    break;

                case "Greater":
                    System.out.println(customList.greater(data[1]));
                    break;

                case "Max":
                    System.out.println(customList.getMax());
                    break;

                case "Min":
                    System.out.println(customList.getMin());
                    break;

                case "Print":
                    customList.print();
                    break;
            }
        }
        scanner.close();
    }
}
