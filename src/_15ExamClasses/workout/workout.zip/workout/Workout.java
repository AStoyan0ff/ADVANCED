package workout;
import java.util.ArrayList;
import java.util.List;

public class Workout {

    private List<Exercise> exercises;
    private String type;
    private int exerciseCount;

    public Workout(String type, int exerciseCount) {

        this.type = type;
        this.exerciseCount = exerciseCount;
        this.exercises = new ArrayList<>();
    }

    public void  addExercise(Exercise exercise) {

        if (exercises.size() < exerciseCount) {
            exercises.add(exercise);
        }
    }

    public boolean removeExercise(String name, String muscle) {
        for (Exercise e : exercises) {

            if (e.getName().equals(name) && e.getMuscle().equals(muscle)) {
                exercises.remove(e);

                return true;
            }
        }
        return false;
    }

    public Exercise getExercise(String name, String muscle) {
        for (Exercise e : exercises) {

            if (e.getName().equals(name) && e.getMuscle().equals(muscle)) {
                return e;
            }
        }
        return null;
    }

    public Exercise getMostBurnedCaloriesExercise() {
        if (exercises.isEmpty()) {
            return null;
        }

        Exercise mostBurned = exercises.get(0);
        for (Exercise exercise : exercises) {
            if (exercise.getBurnedCalories() > mostBurned.getBurnedCalories()) {
                mostBurned = exercise;
            }
        }
        return mostBurned;
    }

    public int getExerciseCount() {
        return exercises.size();
    }

    public String getStatistics() {

        StringBuilder buff = new StringBuilder();
        buff.append(String.format("Workout type: %s", type));

        for (Exercise exercise : exercises) {

            buff.append(System.lineSeparator());
            buff.append(exercise.toString());
        }

        return buff.toString();
    }
}
